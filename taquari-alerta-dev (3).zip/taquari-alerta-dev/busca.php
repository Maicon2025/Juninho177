<?php
include 'includes/db_config.php';

$termo_busca = '';
$noticias = [];

// 1. Verifica se o termo de busca (q) foi passado na URL
if (isset($_GET['q']) && !empty(trim($_GET['q']))) {
    $termo_busca = trim($_GET['q']);
    $param_busca = "%" . $termo_busca . "%"; // Adiciona wildcards para pesquisa LIKE
    
    // 2. Consulta para buscar notícias em TÍTULO, SUBTÍTULO e CONTEÚDO
    $sql = "SELECT id, titulo, subtitulo, categoria, imagem_url 
            FROM noticias 
            WHERE titulo LIKE :param_busca 
               OR subtitulo LIKE :param_busca 
               OR conteudo LIKE :param_busca 
            ORDER BY data_publicacao DESC";
            
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':param_busca', $param_busca, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        $noticias = $stmt->fetchAll();
    } else {
        die("ERRO: Falha ao tentar buscar notícias. Erro no banco de dados.");
    }
    unset($stmt);
} 
// Fechamos a conexão
unset($pdo); 
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados da Busca: <?php echo htmlspecialchars($termo_busca); ?> | Taquari Alerta</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <?php 
    // Reabre a conexão APENAS para o header, que precisa do $pdo para buscar categorias
    include 'includes/db_config.php'; 
    include 'includes/header.php'; 
    unset($pdo);
    ?>

    <main class="container">
        <h2>Resultados para: <span style="color: var(--cor-alerta);"><?php echo htmlspecialchars($termo_busca); ?></span></h2>
        
        <hr>

        <section class="lista-busca">
            <?php if (count($noticias) > 0): ?>
                <p>Encontradas **<?php echo count($noticias); ?>** notícias:</p>
                <div class="grid-noticias">
                    <?php foreach ($noticias as $noticia): ?>
                        <article class="card-noticia">
                            <a href="noticia.php?id=<?php echo $noticia['id']; ?>">
                                <img src="<?php echo htmlspecialchars($noticia['imagem_url']); ?>" alt="<?php echo htmlspecialchars($noticia['titulo']); ?>">
                                <h3><?php echo htmlspecialchars($noticia['titulo']); ?></h3>
                                <span class="categoria-pequena"><?php echo htmlspecialchars($noticia['categoria']); ?></span>
                            </a>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>Nenhuma notícia encontrada com o termo **"<?php echo htmlspecialchars($termo_busca); ?>"**.</p>
                <p>Tente usar palavras-chave diferentes ou mais gerais.</p>
            <?php endif; ?>
        </section>

    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Taquari Alerta. Todos os direitos reservados.</p>
    </footer>

</body>
</html>