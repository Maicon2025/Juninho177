<?php
// Inclui a conexão com o banco de dados (já configurada para Link Nacional)
include 'includes/db_config.php';

$noticias = [];
$destaque_principal = null; 
$noticias_laterais = [];
$noticias_restantes = [];

try {
    // 1. Consulta para buscar o Destaque Principal (a notícia mais recente marcada como destaque)
    $sql_destaque = "SELECT id, titulo, subtitulo, categoria, imagem_url, conteudo FROM noticias WHERE destaque = 1 ORDER BY data_publicacao DESC LIMIT 1";
    $stmt_destaque = $pdo->query($sql_destaque);
    $destaque_principal = $stmt_destaque->fetch();

    // 2. Consulta para buscar as notícias (as 10 mais recentes, excluindo o destaque se ele existir)
    $sql = "SELECT id, titulo, subtitulo, categoria, imagem_url, data_publicacao FROM noticias";
    
    // Se achou um destaque, exclui-o da lista principal
    if ($destaque_principal) {
        $sql .= " WHERE id != " . $destaque_principal['id'];
    }
    
    $sql .= " ORDER BY data_publicacao DESC LIMIT 10";

    $stmt = $pdo->query($sql);
    $noticias = $stmt->fetchAll();

    // Divide as notícias para o layout de destaque
    $noticias_laterais = array_slice($noticias, 0, 2);
    $noticias_restantes = array_slice($noticias, 2);


} catch (PDOException $e) {
    // Se houver erro de SQL (tabela/coluna inexistente), a página exibe o aviso.
    echo '<p style="text-align:center; color: red;">Não foi possível carregar as notícias. A tabela do banco de dados pode estar indisponível.</p>';
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Taquari Alerta - Notícias de ultima hora</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <?php include 'includes/header.php'; ?>

    <main class="container">
        
        <div class="banner-topo">
            
        </div>

        <?php if ($destaque_principal || !empty($noticias_laterais)): ?>
            <section class="secao-principal-grid">
                
                <?php if ($destaque_principal): ?>
                    <div class="manchete-principal">
                        <a href="noticia.php?id=<?php echo $destaque_principal['id']; ?>">
                            <img src="<?php echo $destaque_principal['imagem_url']; ?>" alt="<?php echo $destaque_principal['titulo']; ?>" class="img-manchete">
                            <div class="info">
                                <span class="categoria"><?php echo htmlspecialchars($destaque_principal['categoria']); ?></span>
                                <h2><?php echo htmlspecialchars($destaque_principal['titulo']); ?></h2>
                                <p class="subtitulo"><?php echo htmlspecialchars($destaque_principal['subtitulo']); ?></p>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>

                <div class="noticias-laterais">
                    <?php foreach ($noticias_laterais as $noticia): ?>
                        <article class="card-lateral">
                            <a href="noticia.php?id=<?php echo $noticia['id']; ?>">
                                <img src="<?php echo $noticia['imagem_url']; ?>" alt="<?php echo $noticia['titulo']; ?>">
                                <div class="info-lateral">
                                    <span class="categoria-pequena"><?php echo htmlspecialchars($noticia['categoria']); ?></span>
                                    <h3><?php echo htmlspecialchars($noticia['titulo']); ?></h3>
                                </div>
                            </a>
                        </article>
                        <?php if (count($noticias_laterais) > 1): ?><hr><?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <hr>

        <section class="outras-noticias">
            <h2>Mais Notícias</h2>
            <div class="grid-noticias-3-colunas">
                <?php if (empty($noticias_restantes)): ?>
                    <p>Não há mais notícias para exibir no momento.</p>
                <?php endif; ?>

                <?php foreach ($noticias_restantes as $noticia): ?>
                    <article class="card-noticia">
                        <a href="noticia.php?id=<?php echo $noticia['id']; ?>">
                            <img src="<?php echo $noticia['imagem_url']; ?>" alt="<?php echo $noticia['titulo']; ?>">
                            <h3><?php echo htmlspecialchars($noticia['titulo']); ?></h3>
                            <span class="categoria-pequena"><?php echo htmlspecialchars($noticia['categoria']); ?></span>
                        </a>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

</main>

    <?php
    // Incluindo o código completo do Rodapé aqui (Já com o bloco de direitos autorais + Instagram no final)

    // Garantindo que $categorias (que vem do header) está disponível, 
    // se não estiver, usamos um fallback para não dar erro.
    if (!isset($categorias) || !is_array($categorias)) {
        // Define categorias padrão para o rodapé caso a variável não exista
        $categorias_rodape = ['Geral', 'Esportes', 'Política', 'Saúde']; 
    } else {
        // Usa as categorias reais, limitando a 4 para um rodapé limpo
        $categorias_rodape = array_slice($categorias, 0, 4); 
    }
    ?>

    <footer class="footer-taquari">
        <div class="container footer-grid">
            
            <div class="footer-col footer-col-info">
                <a href="index.php" class="footer-logo-link">
                    
                </a>
                <p class="footer-descricao">
                    Notícias com a marca da verdade. Informação em tempo real sobre Taquari e região.
                </p>
                <p class="footer-contato">
                    E-mail: contato@taquarialerta.com.br
                </p>
            </div>

            <div class="footer-col">
                <h4 class="footer-titulo">Navegue</h4>
                <ul class="footer-links">
                    <li><a href="index.php">Home</a></li>
                    <?php foreach ($categorias_rodape as $cat): ?>
                        <li>
                            <a href="categoria.php?nome=<?php echo urlencode($cat); ?>">
                                <?php echo htmlspecialchars_decode(htmlspecialchars($cat)); ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                    <li><a href="contato.php">Contato</a></li>
                    <li><a href="sobre.php">Sobre Nós</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4 class="footer-titulo">Siga-nos</h4>
                <div class="footer-redes">
                    <a href="https://www.facebook.com/" target="_blank" class="rede-social-icone facebook">F</a>
                    <a href="https://www.instagram.com/taquarialerta/" target="_blank" class="rede-social-icone instagram">I</a>
                    <a href="https://x.com/" target="_blank" class="rede-social-icone twitter">T</a>
                    <a href="https://www.youtube.com/" target="_blank" class="rede-social-icone youtube">Y</a>
                </div>
                
                <h4 class="footer-titulo footer-newsletter-titulo">Assine a Newsletter</h4>
                <form class="footer-newsletter-form">
                    <input type="email" placeholder="Seu melhor e-mail" required>
                    <button type="submit" class="btn-newsletter">Assinar</button>
                </form>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="container footer-bottom-content">
                <p>&copy; <?php echo date('Y'); ?> Taquari Alerta. Todos os direitos reservados. </p>
                
                <a href="https://www.instagram.com/taquarialerta/" target="_blank" class="instagram-link-footer">
                    <img src="assets/img/instagram-logo.png" alt="Instagram Taquari Alerta" class="instagram-logo-footer">
                </a>
                
            </div>
        </div>
    </footer>

</body>
</html>
<?php 
unset($pdo);
?>