<?php
// Inclui a conexão com o banco de dados
include 'includes/db_config.php';

// 1. Verifica se o ID da notícia foi passado na URL
if (isset($_GET['id']) && !empty(trim($_GET['id']))) {
    
    // Sanitiza e armazena o ID
    $id_noticia = trim($_GET['id']);
    
    // 2. Prepara a consulta para buscar a notícia específica
    $sql = "SELECT id, titulo, subtitulo, conteudo, imagem_url, categoria, data_publicacao FROM noticias WHERE id = :id";
    
    if ($stmt = $pdo->prepare($sql)) {
        
        // Liga o ID como um parâmetro para prevenir SQL Injection
        $stmt->bindParam(':id', $id_noticia, PDO::PARAM_INT);
        
        // 3. Executa a consulta
        if ($stmt->execute()) {
            
            // Verifica se a notícia existe
            if ($stmt->rowCount() == 1) {
                
                // Armazena os dados da notícia
                $noticia = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $titulo = $noticia['titulo'];
                $subtitulo = $noticia['subtitulo'];
                $conteudo = $noticia['conteudo'];
                $imagem_url = $noticia['imagem_url'];
                $categoria = $noticia['categoria'];
                $data_publicacao = new DateTime($noticia['data_publicacao']); // Para formatar a data

            } else {
                // Notícia não encontrada
                header("location: 404.php"); // Redireciona para uma página de erro (você pode criá-la)
                exit();
            }
        } else {
            // Erro ao executar a query
            die("ERRO: Falha ao tentar buscar a notícia.");
        }
        unset($stmt);
    }
} else {
    // ID não foi passado ou está vazio, redireciona para a home
    header("location: index.php");
    exit();
}
// Fecha a conexão após a consulta principal
unset($pdo);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($titulo); ?> | Taquari Alerta</title>
    <link rel="stylesheet" href="assets/css/style.css"> 
</head>
<body>

    <?php 
    // Reabre a conexão APENAS para o header, que precisa do $pdo para buscar categorias
    include 'includes/db_config.php'; 
    include 'includes/header.php'; 
    // Fechamos a conexão novamente, agora que o header foi incluído
    unset($pdo); 
    ?>

    <main class="container noticia-completa">
        
        <article>
            <span class="noticia-categoria"><?php echo htmlspecialchars($categoria); ?></span>
            
            <h1 class="noticia-titulo"><?php echo htmlspecialchars($titulo); ?></h1>
            
            <p class="noticia-subtitulo"><?php echo htmlspecialchars($subtitulo); ?></p>
            
            <div class="noticia-meta">
                Publicado em: <strong><?php echo $data_publicacao->format('d/m/Y \à\s H:i'); ?></strong>
            </div>

            <hr>
            
            <?php if (!empty($imagem_url)): ?>
                <figure class="noticia-imagem-principal">
                    <img src="<?php echo htmlspecialchars($imagem_url); ?>" alt="<?php echo htmlspecialchars($titulo); ?>">
                    </figure>
            <?php endif; ?>
            
            <div class="noticia-corpo">
                <?php echo nl2br(htmlspecialchars($conteudo)); ?>
            </div>

            </article>
        
        <aside class="sidebar">
            <h3>Leia Também</h3>
            </aside>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Taquari Alerta. Todos os direitos reservados.</p>
    </footer>

</body>
</html>