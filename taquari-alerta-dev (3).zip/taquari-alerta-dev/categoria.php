<?php
include 'includes/db_config.php';

$categoria_nome = '';
$noticias = [];

// 1. Verifica se o nome da categoria foi passado na URL
if (isset($_GET['nome']) && !empty(trim($_GET['nome']))) {
    $categoria_nome = urldecode(trim($_GET['nome'])); // Decodifica o nome (ex: "Pol%C3%ADcia" -> "Polícia")
    
    // 2. Consulta para buscar notícias filtradas pela categoria
    $sql = "SELECT id, titulo, subtitulo, imagem_url FROM noticias WHERE categoria = :categoria_nome ORDER BY data_publicacao DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':categoria_nome', $categoria_nome, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        $noticias = $stmt->fetchAll();
    } else {
        // Erro ao executar a query
        die("ERRO: Falha ao tentar buscar as notícias da categoria.");
    }
    unset($stmt);
} 
// Fecha a conexão antes de iniciar o HTML
unset($pdo); 
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($categoria_nome); ?> | Taquari Alerta</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <?php 
    // Reabre a conexão APENAS para o header, se o unset($pdo) ocorreu acima
    include 'includes/db_config.php';
    include 'includes/header.php'; 
    unset($pdo);
    ?>

    <main class="container">
        <h2>Notícias em: <span style="color: var(--cor-alerta);"><?php echo htmlspecialchars($categoria_nome); ?></span></h2>
        
        <hr>

        <section class="lista-categoria">
            <?php if (count($noticias) > 0): ?>
                <div class="grid-noticias">
                    <?php foreach ($noticias as $noticia): ?>
                        <article class="card-noticia">
                            <a href="noticia.php?id=<?php echo $noticia['id']; ?>">
                                <img src="<?php echo htmlspecialchars($noticia['imagem_url']); ?>" alt="<?php echo htmlspecialchars($noticia['titulo']); ?>">
                                <h3><?php echo htmlspecialchars($noticia['titulo']); ?></h3>
                                <span class="categoria-pequena"><?php echo htmlspecialchars($categoria_nome); ?></span>
                            </a>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>Desculpe, não há notícias publicadas nesta categoria no momento.</p>
            <?php endif; ?>
        </section>

    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Taquari Alerta. Todos os direitos reservados.</p>
    </footer>

</body>
</html>