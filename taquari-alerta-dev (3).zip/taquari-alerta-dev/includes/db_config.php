<?php
// Configurações do Banco de Dados (Link Nacional)
define('DB_SERVER', 'localhost'); // Geralmente é 'localhost' no Link Nacional
define('DB_USERNAME', 'vevonhnh_taquarialertadb');
define('DB_PASSWORD', 'jyfYDnD8EC3atCBFHD4F');
define('DB_NAME', 'vevonhnh_taquarialertadb');

// Tentativa de conexão com o banco de dados
try {
    $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
    // Configurar o modo de erro do PDO para exceção
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Opcional: Definir charset para evitar problemas de acentuação
    $pdo->exec("set names utf8");

} catch(PDOException $e) {
    // Em caso de erro de conexão, exibe uma mensagem genérica de manutenção.
    die("O site está em manutenção. Tente novamente mais tarde.");
}
?>