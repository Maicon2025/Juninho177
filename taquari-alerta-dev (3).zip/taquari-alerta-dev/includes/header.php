<?php
$categorias = []; 

$sql_categorias = "SELECT DISTINCT categoria FROM noticias WHERE categoria IS NOT NULL AND categoria != '' ORDER BY categoria ASC";

if (isset($pdo)) {
    try {
        $stmt_categorias = $pdo->query($sql_categorias);
        $categorias = $stmt_categorias->fetchAll(PDO::FETCH_COLUMN); 
    } catch (PDOException $e) {
        $categorias = []; 
    }
}
?>

<header class="header-taquari">
    <div class="header-topo container">

        <!-- Botão menu -->
        <div class="menu-toggle" id="menuToggle">
            <span></span>
            <span></span>
            <span></span>
        </div>

        <!-- Logo centralizada -->
        <div class="header-left">
            <a href="index.php" class="logo-link">
                <img src="assets/img/logo_taquarialerta.png" alt="Taquari Alerta Logo" class="logo-animada">
            </a>
        </div>

    </div>

    <!-- Menu de categorias -->
    <nav class="nav-categorias" id="navMenu">
        <div class="container menu-list">
            <a href="index.php" class="menu-item principal">Pagina Inicial</a>
            <?php foreach ($categorias as $cat): ?>
                <a href="categoria.php?nome=<?php echo urlencode($cat); ?>" class="menu-item">
                    <?php echo htmlspecialchars_decode(htmlspecialchars($cat)); ?>
                </a>
            <?php endforeach; ?>
        </div>
    </nav>
</header>

<!-- Script menu mobile -->
<script>
document.getElementById('menuToggle').addEventListener('click', function() {
    this.classList.toggle('open');
    document.getElementById('navMenu').classList.toggle('ativo');
});
</script>
