<?php
// Inicia a sessão (é necessário para usar $_SESSION)
session_start();

// Verifica se a variável de sessão 'loggedin' não está definida ou não é true
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    // Se o usuário não estiver logado, ele é redirecionado para a página de login.
    // O 'dirname($_SERVER["PHP_SELF"])' garante que o redirecionamento funcione corretamente
    // tanto para a raiz do admin quanto para sub-pastas, se existissem.
    header("location: login.php");
    exit;
}
?>