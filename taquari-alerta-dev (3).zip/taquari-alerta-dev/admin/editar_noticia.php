<?php
include '../includes/db_config.php';
include '../includes/auth_check.php';

$noticia_data = null;
$id_noticia = null;

// Parte 1: BUSCAR os dados ATUAIS da notícia
if (isset($_GET['id']) && !empty(trim($_GET['id']))) {
    $id_noticia = trim($_GET['id']);
    
    $sql_fetch = "SELECT * FROM noticias WHERE id = :id";
    if ($stmt_fetch = $pdo->prepare($sql_fetch)) {
        $stmt_fetch->bindParam(':id', $id_noticia, PDO::PARAM_INT);
        if ($stmt_fetch->execute()) {
            if ($stmt_fetch->rowCount() == 1) {
                $noticia_data = $stmt_fetch->fetch(PDO::FETCH_ASSOC);
            } else {
                // Notícia não encontrada
                header("location: gerenciar_noticias.php");
                exit();
            }
        } else {
            die("ERRO: Falha ao buscar dados da notícia.");
        }
        unset($stmt_fetch);
    }
} else {
    // ID não fornecido
    header("location: gerenciar_noticias.php");
    exit();
}

// Parte 2: PROCESSAR o UPDATE (se o formulário for submetido)
if (isset($_POST['submit_edicao'])) {
    
    // Coleta e sanitiza os dados
    $titulo = htmlspecialchars(trim($_POST['titulo']));
    $subtitulo = htmlspecialchars(trim($_POST['subtitulo']));
    $categoria = htmlspecialchars(trim($_POST['categoria']));
    $conteudo = trim($_POST['conteudo']);
    $imagem_url = htmlspecialchars(trim($_POST['imagem_url']));
    $destaque = isset($_POST['destaque']) ? 1 : 0; 

    // Query SQL para UPDATE
    $sql_update = "UPDATE noticias SET 
                    titulo = :titulo, 
                    subtitulo = :subtitulo, 
                    conteudo = :conteudo, 
                    imagem_url = :imagem_url, 
                    categoria = :categoria, 
                    destaque = :destaque 
                    WHERE id = :id";
    
    if ($stmt_update = $pdo->prepare($sql_update)) {
        $stmt_update->bindParam(':titulo', $titulo, PDO::PARAM_STR);
        $stmt_update->bindParam(':subtitulo', $subtitulo, PDO::PARAM_STR);
        $stmt_update->bindParam(':conteudo', $conteudo, PDO::PARAM_STR);
        $stmt_update->bindParam(':imagem_url', $imagem_url, PDO::PARAM_STR);
        $stmt_update->bindParam(':categoria', $categoria, PDO::PARAM_STR);
        $stmt_update->bindParam(':destaque', $destaque, PDO::PARAM_INT);
        $stmt_update->bindParam(':id', $id_noticia, PDO::PARAM_INT);
        
        if ($stmt_update->execute()) {
            // Sucesso! Redireciona para o gerenciamento com status de sucesso
            header("location: gerenciar_noticias.php?status=editado");
            exit();
        } else {
            die("ERRO: Não foi possível atualizar a notícia.");
        }
        unset($stmt_update);
    }
}

unset($pdo);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Notícia #<?php echo $id_noticia; ?> | Admin</title>
    <link rel="stylesheet" href="../assets/css/admin_style.css"> 
</head>
<body>

    <header class="admin-header">
        <h1>Taquari Alerta | ADMIN</h1>
        <nav>
            <a href="index.php">Dashboard</a>
            <a href="adicionar_noticia.php">➕ Adicionar Nova Notícia</a>
            <a href="gerenciar_noticias.php" class="btn-primary">Gerenciar Notícias</a>
        </nav>
    </header>

    <main class="admin-content">
        <h2>Editar Notícia: #<?php echo $id_noticia . ' - ' . htmlspecialchars($noticia_data['titulo']); ?></h2>

        <form action="editar_noticia.php?id=<?php echo $id_noticia; ?>" method="POST">
            
            <label for="titulo">Título Principal (Manchete):</label>
            <input type="text" id="titulo" name="titulo" required maxlength="255" value="<?php echo htmlspecialchars($noticia_data['titulo']); ?>">

            <label for="subtitulo">Subtítulo (Resumo Curto):</label>
            <input type="text" id="subtitulo" name="subtitulo" maxlength="255" value="<?php echo htmlspecialchars($noticia_data['subtitulo']); ?>">

            <label for="categoria">Categoria:</label>
            <select id="categoria" name="categoria" required>
                <option value="Politica" <?php if ($noticia_data['categoria'] == 'Politica') echo 'selected'; ?>>Política</option>
                <option value="Policial" <?php if ($noticia_data['categoria'] == 'Policial') echo 'selected'; ?>>Policial</option>
                <option value="Esportes" <?php if ($noticia_data['categoria'] == 'Esportes') echo 'selected'; ?>>Esportes</option>
                <option value="Geral" <?php if ($noticia_data['categoria'] == 'Geral') echo 'selected'; ?>>Geral</option>
                </select>

            <label for="conteudo">Conteúdo da Notícia:</label>
            <textarea id="conteudo" name="conteudo" rows="15" required><?php echo htmlspecialchars($noticia_data['conteudo']); ?></textarea>

            <label for="imagem_url">URL da Imagem (ou Nome do Arquivo):</label>
            <input type="text" id="imagem_url" name="imagem_url" placeholder="Ex: assets/img/noticia1.jpg" value="<?php echo htmlspecialchars($noticia_data['imagem_url']); ?>">

            <label for="destaque">Destaque na Página Inicial?</label>
            <input type="checkbox" id="destaque" name="destaque" value="1" <?php if ($noticia_data['destaque']) echo 'checked'; ?>> Marcar como Manchete Principal

            <button type="submit" name="submit_edicao">Salvar Alterações</button>
            <a href="gerenciar_noticias.php" class="btn-voltar">Cancelar</a>
        </form>

    </main>

</body>
</html>