<?php
include '../includes/db_config.php';
include '../includes/auth_check.php';

// Verifica se o ID foi passado na URL
if (isset($_GET['id']) && !empty(trim($_GET['id']))) {
    $id_noticia = trim($_GET['id']);
    
    // Query SQL para deletar
    $sql = "DELETE FROM noticias WHERE id = :id";
    
    if ($stmt = $pdo->prepare($sql)) {
        
        // Liga o parâmetro
        $stmt->bindParam(':id', $id_noticia, PDO::PARAM_INT);
        
        // Executa
        if ($stmt->execute()) {
            // Sucesso! Redireciona com status
            header("location: gerenciar_noticias.php?status=excluido");
            exit();
        } else {
            die("ERRO: Não foi possível excluir a notícia.");
        }
        unset($stmt);
    }
} else {
    // Se ID não foi fornecido, volta para o gerenciamento
    header("location: gerenciar_noticias.php");
    exit();
}
unset($pdo);
?>