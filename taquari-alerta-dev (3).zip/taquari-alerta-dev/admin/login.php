<?php
// Inclui a conexão e inicia a sessão
// O caminho '../includes/db_config.php' é NECESSÁRIO se este arquivo estiver dentro da pasta 'admin/'
include '../includes/db_config.php';
session_start();

// Se o usuário já estiver logado, redireciona para o dashboard
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: index.php");
    exit;
}

$username = $password = "";
$username_err = $password_err = $login_err = "";

// Processamento do formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Validação dos inputs
    if (empty(trim($_POST["username"]))) {
        $username_err = "Por favor, insira o nome de usuário.";
    } else {
        $username = trim($_POST["username"]);
    }
    
    if (empty(trim($_POST["password"]))) {
        $password_err = "Por favor, insira a senha.";
    } else {
        $password = trim($_POST["password"]);
    }

    // 2. Processamento da credencial com Tratamento de Erro (try-catch)
    if (empty($username_err) && empty($password_err)) {
        
        // **INÍCIO DO BLOCO TRY-CATCH PARA CAPTURAR ERROS SQL**
        try {
            $sql = "SELECT id, username, password_hash FROM usuarios WHERE username = :username";
            
            if ($stmt = $pdo->prepare($sql)) {
                $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
                $param_username = $username;
                
                if ($stmt->execute()) {
                    if ($stmt->rowCount() == 1) {
                        if ($row = $stmt->fetch()) {
                            $id = $row["id"];
                            // Coloquei o username aqui para garantir que ele seja setado
                            $db_username = $row["username"]; 
                            $hashed_password = $row["password_hash"];
                            
                            // Verifica se a senha fornecida corresponde ao hash no banco
                            if (password_verify($password, $hashed_password)) {
                                // Senha correta, inicia a sessão
                                $_SESSION["loggedin"] = true;
                                $_SESSION["id"] = $id;
                                $_SESSION["username"] = $db_username; 
                                
                                // Redireciona para o painel de administração
                                header("location: index.php");
                            } else {
                                $login_err = "Nome de usuário ou senha inválidos.";
                            }
                        }
                    } else {
                        // Usuário não existe
                        $login_err = "Nome de usuário ou senha inválidos.";
                    }
                } else {
                    // Erro na execução da query (embora o catch pegue a maioria)
                    $login_err = "Ops! O servidor de banco de dados encontrou um problema. Tente novamente mais tarde.";
                }

                unset($stmt);
            }
            
        } catch (PDOException $e) {
            // Este bloco captura erros como "Tabela 'usuarios' não encontrada"
            // Se você quiser ver o erro SQL, descomente a linha abaixo:
            // $login_err = "Erro de Banco de Dados: " . $e->getMessage(); 
            
            $login_err = "Ops! O sistema de login está temporariamente indisponível. Tente novamente mais tarde.";
            
        } // **FIM DO BLOCO TRY-CATCH**
    }
    unset($pdo);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Taquari Alerta Admin</title>
    <link rel="stylesheet" href="../assets/css/admin_style.css"> 
    <style>
        .login-box {
            width: 350px;
            margin: 100px auto;
            padding: 30px;
            background: #FFF;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .login-box h2 { color: #333; margin-bottom: 20px; }
        .alert-danger { 
            color: #721c24; 
            background-color: #f8d7da; 
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        /* Adicione estilos para os inputs, labels e botões para que o formulário apareça bem */
        .login-box label { display: block; text-align: left; margin-top: 10px; font-weight: bold; }
        .login-box input[type="text"], .login-box input[type="password"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 5px 0 15px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .login-box button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Taquari Alerta | Login</h2>
        <p>Por favor, insira suas credenciais para acessar o painel.</p>

        <?php 
        if (!empty($login_err)) {
            echo '<div class="alert-danger">' . $login_err . '</div>';
        }      
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="username">Usuário:</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>">
            <span class="invalid-feedback"><?php echo $username_err; ?></span>

            <label for="password">Senha:</label>
            <input type="password" name="password">
            <span class="invalid-feedback"><?php echo $password_err; ?></span>

            <button type="submit" name="submit_login">Acessar Painel</button>
        </form>
        <p style="margin-top: 20px;"><a href="cadastrar_admin.php">Cadastrar primeiro administrador?</a></p>
    </div>
</body>
</html>