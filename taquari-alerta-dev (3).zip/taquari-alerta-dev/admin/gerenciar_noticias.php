<?php
include '../includes/db_config.php';
include '../includes/auth_check.php';

$mensagem = '';
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'excluido') {
        $mensagem = '<div class="alerta-sucesso">Notícia excluída com sucesso!</div>';
    } elseif ($_GET['status'] == 'editado') {
        $mensagem = '<div class="alerta-sucesso">Notícia atualizada com sucesso!</div>';
    }
}

// Consulta para buscar todas as notícias para exibição
$sql = "SELECT id, titulo, categoria, data_publicacao, destaque FROM noticias ORDER BY data_publicacao DESC";
$stmt = $pdo->query($sql);
$noticias = $stmt->fetchAll();

unset($pdo);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Notícias | Admin</title>
    <link rel="stylesheet" href="../assets/css/admin_style.css"> 
</head>
<body>

    <header class="admin-header">
        <h1>Taquari Alerta | ADMIN</h1>
        <nav>
            <a href="index.php">Dashboard</a>
            <a href="adicionar_noticia.php" class="btn-primary">➕ Adicionar Nova Notícia</a>
            <a href="gerenciar_noticias.php">Gerenciar Notícias</a>
        </nav>
    </header>

    <main class="admin-content">
        <h2>Gerenciar Notícias Publicadas</h2>

        <?php echo $mensagem; ?>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Categoria</th>
                    <th>Publicação</th>
                    <th>Destaque</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($noticias) > 0): ?>
                    <?php foreach ($noticias as $noticia): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($noticia['id']); ?></td>
                            <td><?php echo htmlspecialchars($noticia['titulo']); ?></td>
                            <td><?php echo htmlspecialchars($noticia['categoria']); ?></td>
                            <td><?php echo (new DateTime($noticia['data_publicacao']))->format('d/m/Y H:i'); ?></td>
                            <td><?php echo $noticia['destaque'] ? 'Sim (🔴)' : 'Não'; ?></td>
                            <td class="acoes">
                                <a href="editar_noticia.php?id=<?php echo $noticia['id']; ?>" class="btn-editar">Editar</a>
                                <a href="excluir_noticia.php?id=<?php echo $noticia['id']; ?>" class="btn-excluir" onclick="return confirm('Tem certeza que deseja excluir esta notícia? Esta ação é irreversível.');">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">Nenhuma notícia encontrada. Comece a publicar!</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </main>

</body>
</html>