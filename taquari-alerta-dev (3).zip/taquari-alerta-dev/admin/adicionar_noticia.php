<?php 
// O caminho correto para o db_config.php e auth_check.php deve ser '../includes/'

// Corrigi o caminho da inclusão do auth_check.php para o que você tem no admin
include '../includes/db_config.php';
include 'auth_check.php'; 

// Mensagem de sucesso, se vier do processamento
$mensagem = "";
if (isset($_GET['sucesso']) && $_GET['sucesso'] == 'true') {
    $mensagem = "Notícia publicada com sucesso!";
} elseif (isset($_GET['erro_sql']) && $_GET['erro_sql'] == 'true') {
    $mensagem = "❌ Erro no Banco de Dados! A tabela `noticias` pode estar faltando.";
} elseif (isset($_GET['erro_execucao']) && $_GET['erro_execucao'] == 'true') {
    $mensagem = "Algo deu errado durante a execução da publicação.";
}

// DEFINIÇÃO DAS CATEGORIAS FIXAS DO PAINEL ADMIN
$categorias_fixas = [
    "Brasil" => "Brasil",
    "Mundo" => "Mundo",
    "DF" => "DF",
    "Entretenimento" => "Entretenimento",
    "Vida & Estilo" => "Vida & Estilo",
    "Saude" => "Saúde",
    "Ciencia" => "Ciência",
    "Esportes" => "Esportes",
    "Especiais" => "Especiais",
    // Suas categorias originais, se ainda quiser usá-las:
    "Politica" => "Política",
    "Policial" => "Policial",
    "Geral" => "Geral",
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Notícia | Admin</title>
    <link rel="stylesheet" href="../assets/css/admin_style.css"> 
    <style>
        /* Estilos básicos para o admin_style.css (se não estiverem lá) */
        .alerta-sucesso { 
            background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; 
            padding: 10px; margin-bottom: 20px; border-radius: 4px; 
        }
        .alerta-erro {
            background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;
            padding: 10px; margin-bottom: 20px; border-radius: 4px; 
        }
    </style>
</head>
<body>

    <header class="admin-header">
        <h1>Taquari Alerta | ADMIN</h1>
        <nav>
            <a href="index.php">Dashboard</a>
            <a href="adicionar_noticia.php" class="btn-primary">➕ Adicionar Nova Notícia</a>
        </nav>
    </header>

    <main class="admin-content">
        <h2>Adicionar Nova Notícia</h2>

        <?php if ($mensagem): ?>
            <div class="<?php echo (isset($_GET['sucesso']) && $_GET['sucesso'] == 'true') ? 'alerta-sucesso' : 'alerta-erro'; ?>">
                <?php echo $mensagem; ?>
            </div>
        <?php endif; ?>

        <form action="processar_noticia.php" method="POST" enctype="multipart/form-data">
            
            <label for="titulo">Título Principal (Manchete):</label>
            <input type="text" id="titulo" name="titulo" required maxlength="255">

            <label for="subtitulo">Subtítulo (Resumo Curto):</label>
            <input type="text" id="subtitulo" name="subtitulo" maxlength="255">

            <label for="categoria">Categoria:</label>
            <select id="categoria" name="categoria" required>
                <option value="">-- Selecione uma Categoria --</option>
                
                <?php foreach ($categorias_fixas as $value => $label): ?>
                    <option value="<?php echo htmlspecialchars($value); ?>">
                        <?php echo htmlspecialchars($label); ?>
                    </option>
                <?php endforeach; ?>

            </select>

            <label for="conteudo">Conteúdo da Notícia:</label>
            <textarea id="conteudo" name="conteudo" rows="15" required></textarea>

            <h3>Opções de Imagem Principal:</h3>
            
            <label for="upload_imagem">Fazer Upload de Arquivo (Recomendado):</label>
            <input type="file" id="upload_imagem" name="upload_imagem" accept="image/*">
            
            <p style="margin-top: 10px; margin-bottom: 10px;">OU</p>
            
            <label for="imagem_url">URL Externa da Imagem (Opcional):</label>
            <input type="text" id="imagem_url" name="imagem_url" placeholder="Ex: http://siteexterno.com/foto.jpg">
            
            <label style="margin-top: 15px;">
                <input type="checkbox" id="destaque" name="destaque" value="1"> 
                Marcar como Manchete Principal (Destaque)
            </label>

            <button type="submit" name="submit_noticia">Publicar Notícia</button>
        </form>

    </main>

</body>
</html>