<?php
// Inclui a conexão com o banco de dados
include '../includes/db_config.php';
include 'auth_check.php'; 

// Define o diretório onde as imagens serão salvas
// ATENÇÃO: CRIE ESTA PASTA E GARANTA PERMISSÕES DE ESCRITA!
$upload_dir = '../assets/img/noticias/'; 

if (isset($_POST['submit_noticia'])) {
    
    // 1. Coleta e sanitiza os dados do formulário
    $titulo = htmlspecialchars(trim($_POST['titulo']));
    $subtitulo = htmlspecialchars(trim($_POST['subtitulo']));
    $categoria = htmlspecialchars(trim($_POST['categoria']));
    $conteudo = trim($_POST['conteudo']); 
    
    // A URL da imagem será definida pelo upload ou pelo campo de texto
    $imagem_final = ''; 
    $erro_upload = false;

    // --- LÓGICA DE UPLOAD/URL DA IMAGEM ---
    
    // A) Processar Upload de Arquivo
    if (isset($_FILES['upload_imagem']) && $_FILES['upload_imagem']['error'] == 0) {
        $file = $_FILES['upload_imagem'];
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        $file_size = $file['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // Tipos de arquivo permitidos
        $allowed_ext = array('jpg', 'jpeg', 'png', 'gif');

        if (in_array($file_ext, $allowed_ext)) {
            // Cria nome único baseado no tempo para evitar colisões
            $new_file_name = uniqid('noticia_', true) . '.' . $file_ext;
            $file_destination = $upload_dir . $new_file_name;

            // Tenta mover o arquivo
            if (move_uploaded_file($file_tmp, $file_destination)) {
                // Se o upload foi bem-sucedido, armazena o caminho para o banco
                $imagem_final = 'assets/img/noticias/' . $new_file_name;
            } else {
                $erro_upload = "Erro ao mover o arquivo. Verifique as permissões da pasta 'noticias'.";
            }
        } else {
            $erro_upload = "Formato de arquivo não suportado. Use JPG, PNG ou GIF.";
        }
    } 
    
    // B) Se não houve upload, verificar se há URL de imagem
    elseif (!empty(trim($_POST['imagem_url']))) {
        $imagem_final = htmlspecialchars(trim($_POST['imagem_url']));
    }

    // Se houve erro de upload OU a imagem principal está vazia, interrompe
    if ($erro_upload) {
        // Redireciona com mensagem de erro específica de upload
        header("location: adicionar_noticia.php?erro_upload=". urlencode($erro_upload));
        exit();
    }
    
    // --- FIM DA LÓGICA DE UPLOAD ---

    
    $destaque = isset($_POST['destaque']) ? 1 : 0; 
    
    // 2. Prepara a query SQL para inserção
    $sql = "INSERT INTO noticias (titulo, subtitulo, conteudo, imagem_url, categoria, destaque, data_publicacao) 
             VALUES (:titulo, :subtitulo, :conteudo, :imagem_final, :categoria, :destaque, NOW())";
    
    // 3. Bloco try-catch para capturar erros de SQL ou tabela inexistente
    try {
        if ($stmt = $pdo->prepare($sql)) {
            
            // 4. Liga os parâmetros com as variáveis
            $stmt->bindParam(':titulo', $titulo, PDO::PARAM_STR);
            $stmt->bindParam(':subtitulo', $subtitulo, PDO::PARAM_STR);
            $stmt->bindParam(':conteudo', $conteudo, PDO::PARAM_STR);
            $stmt->bindParam(':imagem_final', $imagem_final, PDO::PARAM_STR); // Usa o caminho final aqui
            $stmt->bindParam(':categoria', $categoria, PDO::PARAM_STR);
            $stmt->bindParam(':destaque', $destaque, PDO::PARAM_INT);
            
            // 5. Executa a declaração
            if ($stmt->execute()) {
                header("location: adicionar_noticia.php?sucesso=true");
                exit();
            } else {
                header("location: adicionar_noticia.php?erro_execucao=true");
                exit();
            }

            unset($stmt);
        }
        
    } catch (PDOException $e) {
        // Erro de BD (provavelmente tabela 'noticias' inexistente)
        header("location: adicionar_noticia.php?erro_sql=true");
        exit();
    }
    
    unset($pdo);

} else {
    header("location: adicionar_noticia.php");
    exit();
}
?>