<?php
// O caminho '../includes/db_config.php' está correto.
include '../includes/db_config.php'; 

// ATENÇÃO: Se auth_check.php estiver na mesma pasta 'admin/', use:
include 'auth_check.php'; 
// Se auth_check.php estiver em 'admin/includes/', use:
// include 'includes/auth_check.php';

// Verifique a localização exata do seu arquivo de verificação de autenticação!
// O Erro 500 pode estar aqui se o caminho estiver errado.

// ... (O restante do seu código index.php permanece inalterado)

// Esta é a página principal do Painel.
// No futuro, você listaria aqui as últimas notícias publicadas.
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Admin | Taquari Alerta</title>
    <link rel="stylesheet" href="../assets/css/admin_style.css"> 
</head>
<body>

    <header class="admin-header">
        <h1>Taquari Alerta | ADMIN</h1>
        <nav>
            <a href="index.php">Dashboard</a>
            <a href="adicionar_noticia.php">Adicionar Notícia</a>
            <a href="gerenciar_noticias.php">Gerenciar Notícias</a>
            
            <a href="cadastrar_admin.php" class="btn-primary">👤 Cadastrar Admin</a> 
            
            <a href="logout.php">Sair</a>
        </nav>
    </header>

    <main class="admin-content">
        <h2>Bem-vindo ao Painel de Administração!</h2>
        <p>Use os links abaixo para gerenciar o conteúdo e os usuários do seu portal.</p>
        
        <div class="quick-links">
            
            <a href="adicionar_noticia.php" class="card-link">
                <h3>Publicar Notícia</h3>
                <p>Crie e envie uma nova reportagem para o site.</p>
            </a>
            
            <a href="gerenciar_noticias.php" class="card-link">
                <h3>Gerenciar Notícias</h3>
                <p>Editar, excluir ou visualizar o status das notícias existentes.</p>
            </a>
            
            <a href="cadastrar_admin.php" class="card-link link-admin-user">
                <h3>Cadastrar Administrador</h3>
                <p>Adicione um novo usuário com acesso ao painel de administração.</p>
            </a>
            
        </div>
        
        <div style="margin-top: 30px;">
            <a href="logout.php" class="btn-danger">Sair do Painel</a>
        </div>

    </main>
    
    <footer class="admin-footer">
        <p>&copy; <?php echo date("Y"); ?> Taquari Alerta Admin</p>
    </footer>
    
</body>
</html>