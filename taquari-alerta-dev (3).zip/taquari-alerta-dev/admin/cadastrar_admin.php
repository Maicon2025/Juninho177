<?php
// Inclui o arquivo de configuração do banco (caminho: voltando 1 nível)
require_once '../includes/db_config.php';
session_start(); 

//equire_once 'auth_check.php'; 

$mensagem_status = '';

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $novo_login = trim($_POST['novo_login']);
    $nova_senha = $_POST['nova_senha'];
    $confirmar_senha = $_POST['confirmar_senha'];

    // 1. Validação básica
    if (empty($novo_login) || empty($nova_senha) || empty($confirmar_senha)) {
        $mensagem_status = '<p class="erro">Todos os campos são obrigatórios.</p>';
    } elseif ($nova_senha !== $confirmar_senha) {
        $mensagem_status = '<p class="erro">A senha e a confirmação de senha não coincidem.</p>';
    } else {
        // 2. Cria o hash seguro da nova senha
        $senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
        
        // 3. Insere o novo usuário no banco de dados
        $coluna_login = 'username'; 

        $sql = "INSERT INTO usuarios ({$coluna_login}, password_hash) VALUES (:novo_login, :senha_hash)";
        
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':novo_login', $novo_login, PDO::PARAM_STR);
            $stmt->bindParam(':senha_hash', $senha_hash, PDO::PARAM_STR);
            
            if ($stmt->execute()) {
                $mensagem_status = '<p class="sucesso">Novo administrador <strong>' . htmlspecialchars($novo_login) . '</strong> cadastrado com sucesso!</p>';
            } else {
                $mensagem_status = '<p class="erro">Erro ao cadastrar administrador. Tente novamente.</p>';
            }
        } catch (PDOException $e) {
            if ($e->getCode() == '23000') {
                 $mensagem_status = '<p class="erro">Erro: O nome de login já está em uso.</p>';
            } else {
                 // **MENSAGEM CRÍTICA: VERIFIQUE A TABELA `usuarios` NO PHPMYADMIN**
                 $mensagem_status = '<p class="erro">Falha no Banco de Dados. Verifique a tabela `usuarios`.</p>';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Administrador | Taquari Alerta Admin</title>
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <style>
        .form-admin { max-width: 500px; margin: 20px auto; padding: 20px; background: #FFF; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .form-admin label { display: block; margin-top: 10px; font-weight: bold; }
        .form-admin input { width: calc(100% - 22px); padding: 10px; margin-bottom: 15px; border: 1px solid #CCC; border-radius: 4px; box-sizing: border-box; }
        .form-admin button { background-color: #28a745; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; }
        .sucesso { color: green; background: #e9f7ef; padding: 10px; border-radius: 4px; border: 1px solid green; }
        .erro { color: red; background: #fbe6e6; padding: 10px; border-radius: 4px; border: 1px solid red; }
        .btn-voltar { display: inline-block; margin-bottom: 20px; padding: 8px 15px; background-color: #6c757d; color: white; border-radius: 4px; text-decoration: none;}
    </style>
</head>
<body>

    <?php include 'header.php'; ?> 

    <main class="container">
        <h2>Cadastrar Novo Administrador</h2>
        <a href="index.php" class="btn-voltar">← Voltar para o Painel</a>
        
        <?php echo $mensagem_status; ?>

        <form action="cadastrar_admin.php" method="POST" class="form-admin">
            
            <label for="novo_login">Login (Nome de Usuário):</label>
            <input type="text" id="novo_login" name="novo_login" required>

            <label for="nova_senha">Senha:</label>
            <input type="password" id="nova_senha" name="nova_senha" required>

            <label for="confirmar_senha">Confirmar Senha:</label>
            <input type="password" id="confirmar_senha" name="confirmar_senha" required>

            <button type="submit" class="btn-primary">Cadastrar Administrador</button>
        </form>

    </main>

    <?php include 'footer.php'; ?>

</body>
</html>